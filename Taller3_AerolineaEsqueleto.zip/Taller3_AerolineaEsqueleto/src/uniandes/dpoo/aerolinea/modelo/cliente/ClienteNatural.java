package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural {

}
